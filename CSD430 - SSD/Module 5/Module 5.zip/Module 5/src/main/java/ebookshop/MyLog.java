package ebookshop;

public class MyLog {

}
