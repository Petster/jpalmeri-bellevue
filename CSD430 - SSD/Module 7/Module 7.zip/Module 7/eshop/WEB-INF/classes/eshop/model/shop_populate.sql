INSERT INTO `shop`.`categories` (`category_id`, `category_name`) VALUES ('1', 'Web Development');
INSERT INTO `shop`.`categories` (`category_id`, `category_name`) VALUES ('2', 'Science Fiction');
INSERT INTO `shop`.`categories` (`category_id`, `category_name`) VALUES ('3', 'Historical Mysteries');
INSERT INTO `shop`.`books` (`book_id`, `title`, `author`, `price`, `category_id`) VALUES ('1', 'MYSQL 8 Query Performance Tuning', 'Jesper Wisborg Krogh', '34.31', '1');
INSERT INTO `shop`.`books` (`book_id`, `title`, `author`, `price`, `category_id`) VALUES ('2', 'JavaScript Next', 'Raju Gandhi', '36.70', '1');
INSERT INTO `shop`.`books` (`book_id`, `title`, `author`, `price`, `category_id`) VALUES ('3', 'The Complete Robot', 'Isaac Asimov', '12.13', '2');
INSERT INTO `shop`.`books` (`book_id`, `title`, `author`, `price`, `category_id`) VALUES ('4', 'Foundation and Earth', 'Isaac Asimov', '11.07', '2');
INSERT INTO `shop`.`books` (`book_id`, `title`, `author`, `price`, `category_id`) VALUES ('5', 'The Da Vinci Code', 'Dan Brown', '7.99', '3');
INSERT INTO `shop`.`books` (`book_id`, `title`, `author`, `price`, `category_id`) VALUES ('6', 'A Column of Fire', 'Ken Follett', '6.99', '3');
