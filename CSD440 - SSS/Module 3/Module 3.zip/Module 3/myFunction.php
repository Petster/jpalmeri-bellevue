<?php

function sumOf($x, $y) {
    return $x + $y;
}