"use strict";
let home = document.getElementById('homelink');
let about = document.getElementById('aboutlink');
let hobby = document.getElementById('hobbylink');

$(document).ready(function() {
    if (window.location.href.indexOf("#home") > -1) {
        hobby.classList.remove('nav-link-underline');
        about.classList.remove('nav-link-underline');
    } else if (window.location.href.indexOf("#about") > -1) {
        hobby.classList.remove('nav-link-underline');
        about.classList.add('nav-link-underline');
    } else if (window.location.href.indexOf("#hobby") > -1) {
        hobby.classList.add('nav-link-underline');
        about.classList.remove('nav-link-underline');
    }
  });

home.addEventListener('click', function() {
    console.log("home");
    hobby.classList.remove('nav-link-underline');
    about.classList.remove('nav-link-underline');
});

about.addEventListener('click', function() {
    console.log("about");
    hobby.classList.remove('nav-link-underline');
    about.classList.add('nav-link-underline');
});

hobby.addEventListener('click', function() {
    console.log("hobby");
    about.classList.remove('nav-link-underline');
    hobby.classList.add('nav-link-underline');
});